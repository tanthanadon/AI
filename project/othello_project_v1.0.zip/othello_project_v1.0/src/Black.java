public class Black{
    public final static Player player = new RandomPlayer(OthelloGame.B);
}