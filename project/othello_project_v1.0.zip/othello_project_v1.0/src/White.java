public class White{
    public final static Player player = new RandomPlayer(OthelloGame.W);
}